# HeartSync Demo
App de demonstração com IA para compatibilidade de perfis.